﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Punto_3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int valor1;
            string linea;


            Console.Write("Ingrese un numero ");
            linea = Console.ReadLine();
            valor1 = int.Parse(linea);

            if (valor1 > 9 && valor1 <= 99)
            {
                Console.Write("El numero tiene 2 digitos");
            }
            else
            {
                Console.Write("El numero tiene 1 digito");
            }

        }

    }
}
