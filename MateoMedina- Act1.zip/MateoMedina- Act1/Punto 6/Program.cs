﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Punto_6
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double peso, altura, imc;
            string linea;

            Console.Write("Escriba su peso ");
            linea = Console.ReadLine();
            peso = double.Parse(linea);

            Console.Write("Escriba su altura ");
            linea = Console.ReadLine();
            altura = double.Parse(linea);

            imc = peso / (altura * altura);

            Console.Write("Tu indice de masa corporal es de " + imc );
            //poner con coma el peso y la altura 
            Console.ReadKey();
        }
    }
}
