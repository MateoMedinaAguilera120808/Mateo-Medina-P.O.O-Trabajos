﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace Punto_1
{
    internal class Program
    {

        //1. Realizar la carga del lado de un cuadrado, mostrar por pantalla el perímetro del mismo (El perímetro de un cuadrado se calcula multiplicando el valor del lado por cuatro).


        static void Main(string[] args)
        {
            int lado = 0;
            int perimetro = 0;
            string linea;

            Console.Write("ingrese el largo del lado del cuadrado= ");
            linea = Console.ReadLine();
            lado = int.Parse(linea);

            perimetro = lado * 4;


            Console.Write("El perimetro del cuadrado es = " + perimetro );


            Console.ReadKey();
        }
    }
}
