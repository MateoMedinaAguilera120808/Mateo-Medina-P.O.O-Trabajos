﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Punto_2
{
    internal class Program
    {
        static void Main(string[] args)
        {

            //2. Escribir un programa en el cual se ingresen cuatro números, calcular e informar la suma de los dos primeros y el producto del tercero y el cuarto.


            int valor1, valor2, valor3, valor4, suma, producto;
            string linea;

            Console.Write("Escriba el valor del primer numero= ");
            linea = Console.ReadLine();
            valor1 = int.Parse(linea);

            Console.Write("Escriba el valor del segundo numero= ");
            linea = Console.ReadLine();
            valor2 = int.Parse(linea);

            Console.Write("Escriba el valor del tercer numero= ");
            linea = Console.ReadLine();
            valor3 = int.Parse(linea);

            Console.Write("Escriba el valor del cuarto numero= ");
            linea = Console.ReadLine();
            valor4 = int.Parse(linea);

            suma = valor1 + valor2;

            producto = valor3 * valor4;


            Console.Write("la suma de los valores 1 y 2 es " + suma + "  Y el producto de los valores 3 y 4 es " + producto);
        

            Console.ReadKey();
        }
    }
}
