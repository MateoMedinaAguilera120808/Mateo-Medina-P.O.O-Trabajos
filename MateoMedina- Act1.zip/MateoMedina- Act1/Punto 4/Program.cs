﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Punto_4
{
    internal class Program
    {


        //4. Se debe desarrollar un programa que pida el ingreso del precio de un artículo y la cantidad que lleva el cliente. Mostrar lo que debe abonar el comprador.


        static void Main(string[] args)
        {
            int precio, cantidad, total;
            string linea;


            Console.Write("Escriba el precio del objeto que quiera = ");
            linea = Console.ReadLine();
            precio = int.Parse(linea);

            Console.Write("Escriba la cantidad de objetos que quiera = ");
            linea = Console.ReadLine();
            cantidad = int.Parse(linea);

            total = precio * cantidad;


            Console.Write("El total a abonar es = " + total );

            Console.ReadKey();
        }
    }
}
