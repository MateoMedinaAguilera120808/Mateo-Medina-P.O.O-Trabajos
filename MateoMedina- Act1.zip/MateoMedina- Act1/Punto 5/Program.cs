﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Punto_5
{
    internal class Program
    {

        //5. Realizar la carga del radio de un círculo, mostrar por pantalla la circunferencia y el área del mismo (La circunferencia se calcula multiplicando el doble del radio por π (pi), y el área se calcula multiplicando π por el cuadrado del radio).


        static void Main(string[] args)
        {
            int radio;
            double  circunferencia, area;
            string linea;



            Console.Write("Escriba el radio de un circulo = ");
            linea = Console.ReadLine();
            radio = int.Parse(linea);

            circunferencia = 2 * Math.PI * radio;

            area = Math.PI * (radio * radio);


            Console.Write("La circunferencia de " + radio + " es " + circunferencia + " y su area es " + area);


            Console.ReadKey();
        }
    }
}
