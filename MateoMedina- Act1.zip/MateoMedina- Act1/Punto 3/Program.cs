﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Punto_3
{
    internal class Program
    {
        static void Main(string[] args)
        {


            //3. Realizar un programa que lea cuatro valores numéricos e informar su suma y promedio.


            int valor1, valor2, valor3, valor4, suma, promedio;
            string linea;

            Console.Write("Escriba el valor del primer numero= ");
            linea = Console.ReadLine();
            valor1 = int.Parse(linea);

            Console.Write("Escriba el valor del segundo numero= ");
            linea = Console.ReadLine();
            valor2 = int.Parse(linea);

            Console.Write("Escriba el valor del tercer numero= ");
            linea = Console.ReadLine();
            valor3 = int.Parse(linea);

            Console.Write("Escriba el valor del cuarto numero= ");
            linea = Console.ReadLine();
            valor4 = int.Parse(linea);

            suma = valor1 + valor2 + valor3 + valor4;

            promedio = (valor1 + valor2 + valor3 + valor4) / 4 ;


            Console.Write("La suma de todos los valores es " + suma + " Y el promedio de todo es " +  promedio);

            Console.ReadKey();

        }
    }
}
