﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Punto_5
{
    internal class Program
    {
        //5. Escribir un programa que pida ingresar la coordenada de un punto en el plano, es decir dos valores enteros x e y (distintos a cero).
        //Posteriormente imprimir en pantalla en que cuadrante se ubica dicho punto. (1º Cuadrante si x > 0 Y y > 0 , 2º Cuadrante: x < 0 Y y > 0). 

        static void Main(string[] args)
        {
            int x, y;
            string linea;

            Console.Write("Ingrese un valor para x ");
            linea = Console.ReadLine();
            x = int.Parse(linea);
            

            Console.Write("Ingrese un valor para y ");
            linea = Console.ReadLine();
            y = int.Parse(linea);
            if(y == 0 ||  x== 0) {
                Console.WriteLine("un numero diferente a 0");
            }

            if (y > 0 && x > 0)
            {
                Console.WriteLine("El punto se encuentra en el primer cuadrante");
            }
            if (y > 0 && x < 0) {
                Console.WriteLine("El punto se encuentra en el segundo cuadrante");
            
            }

            Console.ReadKey();
        }
    }
}
