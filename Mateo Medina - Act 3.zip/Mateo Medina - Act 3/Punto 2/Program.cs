﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Punto_2
{
    internal class Program
    {

        //2. Se ingresan tres valores por teclado, si todos son iguales se imprime la suma del primero con el segundo y a este resultado se lo multiplica por el tercero.

        static void Main(string[] args)
        {
            int num1, num2, num3, suma, multiplicacion;
            string linea;

            Console.Write("Ingrese un numero =");
            linea = Console.ReadLine();
            num1 = int.Parse(linea);

            Console.Write("Ingrese otro numero =");
            linea = Console.ReadLine();
            num2 = int.Parse(linea);

            Console.Write("Ingrese otro numero =");
            linea = Console.ReadLine();
            num3 = int.Parse(linea);



            if (num1 == num2 && num1 == num3)            {
                suma = num1 + num2;
                multiplicacion = suma * num3;
                Console.WriteLine("La suma de los numeros es = " + suma);
                Console.Write("La multiplicacion de la suma por el tercer numero es = " + multiplicacion);

            }
            Console.ReadKey();
        }
        
    }
}