﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Punto_1
{
    //1. Realizar un programa que pida cargar una fecha cualquiera, luego verificar si dicha fecha corresponde a Navidad.


    internal class Program
    {
        static void Main(string[] args)
        {
            int dia, mes;
            string linea;

            Console.Write("Ingrese una dia =  ");
            linea = Console.ReadLine();
            dia = int.Parse(linea);


            Console.Write("Ingrese un mes = ");
            linea = Console.ReadLine();
            mes = int.Parse(linea);

            if ((dia == 25) && (mes == 12))
            {
                Console.WriteLine("Es navidad");
            }

            else
            {
                Console.WriteLine("No es navidad");
            }

            Console.ReadKey();
        }
    }
}